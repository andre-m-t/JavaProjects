package poov.batalhanaval.controller;

import java.io.IOException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ColorPicker;
import javafx.scene.control.TextField;
import poov.batalhanaval.App;
import poov.batalhanaval.model.Jogo;

public class SecondaryController extends App {
     @FXML
    private Button goButton;

    @FXML
    private ColorPicker playerDoisCor;

    @FXML
    private TextField playerDoisTextField;

    @FXML
    private ColorPicker playerUmCor;

    @FXML
    private TextField playerUmTextField;

    @FXML
    private Button secondaryButton;

    @FXML
    void goSelected(ActionEvent event) throws IOException{
        Jogo novo = App.obterJogo();
        novo.getPlayer_1().setNome(playerUmTextField.getText());
        novo.getPlayer_2().setNome(playerDoisTextField.getText());
        novo.getPlayer_1().setCor(playerUmCor.getValue());
        novo.getPlayer_2().setCor(playerDoisCor.getValue());
        // System.out.println(novo.getPlayer_1().getPecasDisp().toString());
        App.definirJogo(novo);
        Alert informe = new Alert(AlertType.INFORMATION);
        informe.setTitle("LEIA");
        informe.setHeaderText("Bem vindo a Batalha Naval para posicionar\nsuas peças basta selecionar um botão como\ninicial e após isso escolha se quer posicionar \nna vertical ou horizontal!");
        informe.showAndWait();
        App.setRoot("tableOne");
    }

    @FXML
    private void switchToPrimary() throws IOException {
        App.setRoot("primary");
    }
}