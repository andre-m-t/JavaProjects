package poov.batalhanaval;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.stage.Stage;
import poov.batalhanaval.model.Jogo;
import poov.batalhanaval.model.Opcao;
import poov.batalhanaval.model.Player;
import poov.batalhanaval.model.Tabuleiro;
import poov.batalhanaval.model.Tipo;
import poov.batalhanaval.model.pecasdisp.Couracado;
import poov.batalhanaval.model.pecasdisp.PortaAvioes;
import poov.batalhanaval.model.pecasdisp.Submarino;

import java.io.IOException;
import java.util.ArrayList;

public class App extends Application {

    private static Scene scene;
    private static Opcao definicoesIniciais = new Opcao(10, 10, 3, 1, 2);
    private static Tabuleiro tabuleiro = new Tabuleiro(definicoesIniciais.getLinhas(), definicoesIniciais.getColunas(), null);
    private static Submarino submarino = new Submarino(definicoesIniciais.getSubmarinos(), Tipo.SUBMARINO, 0, null);
    private static Couracado couracado = new Couracado(definicoesIniciais.getCouracados(), Tipo.COURACADO, 0, null);
    private static PortaAvioes portaAvioes = new PortaAvioes(definicoesIniciais.getPortaAvioes(), Tipo.PORTA_AVIAO, 0, null);
    private static Player playerUm = new Player(1, null, tabuleiro, criarSubmarinos(submarino.getQuantidade()), criarCouracados(couracado.getQuantidade()), criarPortaAvioes(portaAvioes.getQuantidade()));
    private static Player playerDois = new Player(2, null, tabuleiro, criarSubmarinos(submarino.getQuantidade()), criarCouracados(couracado.getQuantidade()), criarPortaAvioes(portaAvioes.getQuantidade()));
    private static Jogo novJogo = new Jogo(playerUm, playerDois, definicoesIniciais);
    
    @Override
    public void start(Stage stage) throws IOException {
        scene = new Scene(loadFXML("primary"), 600, 410);
        Image imagem = new Image(getClass().getResourceAsStream("/poov/images/batalhaNavalicon.png"));
        stage.setScene(scene);
        stage.setTitle("Batalha Naval");
        stage.getIcons().add(imagem);
        stage.show();
    }
    
    public static void setOpcoes(Opcao nova){
        definicoesIniciais = nova;
        tabuleiro.setRow(nova.getLinhas());
        tabuleiro.setColumn(nova.getColunas());
        submarino.setQuantidade(nova.getSubmarinos());
        couracado.setQuantidade(nova.getCouracados());
        portaAvioes.setQuantidade(nova.getPortaAvioes());
        playerUm = new Player(1, null, tabuleiro, criarSubmarinos(submarino.getQuantidade()), criarCouracados(couracado.getQuantidade()), criarPortaAvioes(portaAvioes.getQuantidade()));
        playerDois = new Player(2, null, tabuleiro, criarSubmarinos(submarino.getQuantidade()), criarCouracados(couracado.getQuantidade()), criarPortaAvioes(portaAvioes.getQuantidade()));
        novJogo = new Jogo(playerUm, playerDois, definicoesIniciais);
    }
    public static ArrayList<Submarino> criarSubmarinos(int num){
        ArrayList<Submarino> novo = new ArrayList<>();
        for(int i=1;i<=num;i++){
            Submarino nSubmarino = new Submarino(definicoesIniciais.getSubmarinos(), Tipo.SUBMARINO, i, null);
            novo.add(nSubmarino);
        }
        return novo;
    }
    public static ArrayList<Couracado> criarCouracados(int num){
        ArrayList<Couracado> novo = new ArrayList<>();
        for(int i=1;i<=num;i++){
            Couracado nCouracado = new Couracado(definicoesIniciais.getCouracados()
            , Tipo.COURACADO, i, null);
            novo.add(nCouracado);
        }
        return novo;
    }
    public static ArrayList<PortaAvioes> criarPortaAvioes(int num){
        ArrayList<PortaAvioes> novo = new ArrayList<>();
        for(int i=1;i<=num;i++){
            PortaAvioes nPortaAvioes = new PortaAvioes(definicoesIniciais.getPortaAvioes(), Tipo.PORTA_AVIAO, i, null);
            novo.add(nPortaAvioes);
        }
        return novo;
    }
    public static Jogo obterJogo(){
        return novJogo;
    }
    public static void setRoot(String fxml) throws IOException {
        scene.setRoot(loadFXML(fxml));
    }

    private static Parent loadFXML(String fxml) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(App.class.getResource(fxml + ".fxml"));
        return fxmlLoader.load();
    }

    public static void main(String[] args) {
        launch();
    }

}