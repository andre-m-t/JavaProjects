package poov.batalhanaval.model;

public class Posicao {
    private int row;
    private int column;
    public int getRow() {
        return row;
    }
    public void setRow(int row) {
        this.row = row;
    }
    public int getColumn() {
        return column;
    }
    public void setColumn(int column) {
        this.column = column;
    }
    public Posicao(int row, int column) {
        this.row = row;
        this.column = column;
    }
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + row;
        result = prime * result + column;
        return result;
    }
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        Posicao other = (Posicao) obj;
        if (row != other.row)
            return false;
        if (column != other.column)
            return false;
        return true;
    }
    @Override
    public String toString() {
        return "Row: " + row + "Column: " + column;
    }
    
}
