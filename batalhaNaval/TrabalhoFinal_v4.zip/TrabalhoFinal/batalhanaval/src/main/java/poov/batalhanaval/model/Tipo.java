package poov.batalhanaval.model;

public enum Tipo {
    SUBMARINO("Submarino"),
    PORTA_AVIAO("Porta Avião"),
    COURACADO("Couraçado");

    private String descricao;
    
    private Tipo (String descricao){
        this.descricao = descricao;
    }
    public String geDescricao(){
        return descricao;
    }

}
