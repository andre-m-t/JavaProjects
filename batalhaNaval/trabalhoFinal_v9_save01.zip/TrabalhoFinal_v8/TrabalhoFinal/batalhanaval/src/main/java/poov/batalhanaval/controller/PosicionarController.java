package poov.batalhanaval.controller;

import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.layout.GridPane;
import poov.batalhanaval.App;
import poov.batalhanaval.model.Jogo;
import poov.batalhanaval.model.Parte;
import poov.batalhanaval.model.Peca;
import poov.batalhanaval.model.Tipo;

public class PosicionarController implements Initializable{

    @FXML
    private GridPane gridPane;
    private boolean subClcd = false;
    private boolean crcClcd = false;
    private boolean prtClcd = false;
    private int ordem = 1;
    private int cont = 1;
    private int idPeca;
    private ArrayList<Parte> partes = new ArrayList<>();
    private Jogo jogo = App.obterJogo();
    @Override
    public void initialize(URL location, ResourceBundle resources) {
        int newId = 0;
        for(int i =0; i<jogo.getDefinicoes().getLinhas();i++){
            for(int j=0; j<jogo.getDefinicoes().getColunas();j++){
                Button nButton = new Button();
                nButton.setId(String.valueOf(newId));
                newId++;
                nButton.setMinSize(40, 40);
                nButton.setOnAction((javafx.event.EventHandler<ActionEvent>) new EventHandler<ActionEvent>(){
                    public void handle(ActionEvent e){
                        //CONVERTENDO TO STRING DO BOTAO PARA APENAS NUMEROS E SUBSTITUINDO LETRAS POR VAZIO
                        String id = e.getSource().toString().replaceAll("[\\D]", "");
                        Peca clicada = jogo.getPlayer_1().getTabuleiro().getTodasPecas().get(Integer.valueOf(id));
                        if(!subClcd && ordem == 1){
                            initiSubmarine(clicada.getPedacos().get(0), clicada);
                        }
                        if(!crcClcd && ordem == 2){
                            initiCourc(clicada.getPedacos().get(0));
                        }
                        if(!prtClcd && ordem == 3){
                            initiPort(clicada.getPedacos().get(0));
                        }
                        // System.out.println(clicada.toString());
                    }
                });
                gridPane.add(nButton, j, i);
            }
        }
    }
    public void initiSubmarine(Parte nova, Peca usada){
        if(partes == null || partes.size() < Tipo.SUBMARINO.getTamanho()){
            if(partes == null || partes.size() == 0){
                idPeca = usada.getId();
            }
            partes.add(nova);
            usada.setTipo(Tipo.SUBMARINO);
            usada.setQuantidade(jogo.getDefinicoes().getSubmarinos());
            usada.setPedacos(partes);
            usada.setId(idPeca);
            jogo.getPlayer_1().getTabuleiro().getTodasPecas().set(usada.getId(), usada);
            jogo.getPlayer_1().getPecasDisp().set(cont-1, usada);
            Button nButton = new Button(Tipo.SUBMARINO.geDescricao());
            nButton.setMinSize(40, 40);
            gridPane.add(nButton, nova.getColumn(), nova.getRow());
            if(partes.size() == Tipo.SUBMARINO.getTamanho()){
                jogo.getPlayer_1().getTabuleiro().getTodasPecas().set(usada.getId(), usada);
                jogo.getPlayer_1().getPecasDisp().set(cont-1, usada);
            }
        }else{
            if(cont >= jogo.getDefinicoes().getSubmarinos()){
                subClcd = true;
                ordem++;
                partes = new ArrayList<>();
                System.out.println(jogo.getPlayer_1().getPecasDisp().toString());
            }else{

                partes = new ArrayList<>();
                cont++;
            }
            
        }
    }
    public void initiCourc(Parte nova){
        partes.add(nova);
        System.out.println(partes.toString());
    }
    public void initiPort(Parte nova){
        partes.add(nova);
        System.out.println(partes.toString());
    }
}
