package poov.batalhanaval.model;

import java.util.ArrayList;

public class Tabuleiro {
    private int row;
    private int column;
    private ArrayList<PosicoesOcupadas> ocupadas;
    public int getRow() {
        return row;
    }
    public void setRow(int row) {
        this.row = row;
    }
    public int getColumn() {
        return column;
    }
    public void setColumn(int column) {
        this.column = column;
    }
    public ArrayList<PosicoesOcupadas> getOcupadas() {
        return ocupadas;
    }
    public void setOcupadas(ArrayList<PosicoesOcupadas> ocupadas) {
        this.ocupadas = ocupadas;
    }
    public Tabuleiro(int row, int column, ArrayList<PosicoesOcupadas> ocupadas) {
        this.row = row;
        this.column = column;
        this.ocupadas = ocupadas;
    }
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + row;
        result = prime * result + column;
        result = prime * result + ((ocupadas == null) ? 0 : ocupadas.hashCode());
        return result;
    }
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        Tabuleiro other = (Tabuleiro) obj;
        if (row != other.row)
            return false;
        if (column != other.column)
            return false;
        if (ocupadas == null) {
            if (other.ocupadas != null)
                return false;
        } else if (!ocupadas.equals(other.ocupadas))
            return false;
        return true;
    }
    @Override
    public String toString() {
        return "Tabuleiro [row=" + row + ", column=" + column + ", ocupadas=" + ocupadas + "]";
    }
    
}
