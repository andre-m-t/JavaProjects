package poov.batalhanaval;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.stage.Stage;
import poov.batalhanaval.model.Jogo;
import poov.batalhanaval.model.Opcao;
import poov.batalhanaval.model.Parte;
import poov.batalhanaval.model.Peca;
import poov.batalhanaval.model.Player;
import poov.batalhanaval.model.Tabuleiro;
import poov.batalhanaval.model.Tipo;

import java.io.IOException;
import java.util.ArrayList;

public class App extends Application {

    private static Scene scene;
    private static Opcao definicoesIniciais = new Opcao(10, 10, 3, 1, 2);
    private static Tabuleiro tabuleiro = new Tabuleiro(definicoesIniciais.getLinhas(), definicoesIniciais.getColunas(), criarPosicoesOcupadas((definicoesIniciais.getSubmarinos()+definicoesIniciais.getCouracados()+definicoesIniciais.getPortaAvioes())));
    private static ArrayList<Peca> pecas = new ArrayList<>();
    private static Player playerUm = new Player(1, null, tabuleiro, pecas);
    private static Player playerDois = new Player(2, null, tabuleiro, pecas);
    private static Jogo novJogo = new Jogo(playerUm, playerDois, definicoesIniciais);
    
    @Override
    public void start(Stage stage) throws IOException {
        scene = new Scene(loadFXML("primary"), 600, 410);
        Image imagem = new Image(getClass().getResourceAsStream("/poov/images/batalhaNavalicon.png"));
        stage.setScene(scene);
        stage.setTitle("Batalha Naval");
        stage.getIcons().add(imagem);
        stage.show();
    }
    
    public static void setOpcoes(Opcao nova){
        definicoesIniciais = nova;
        tabuleiro.setRow(nova.getLinhas());
        tabuleiro.setColumn(nova.getColunas());
        tabuleiro.setOcupadas(criarPosicoesOcupadas((definicoesIniciais.getSubmarinos()+definicoesIniciais.getCouracados()+definicoesIniciais.getPortaAvioes())));
        submarino.setQuantidade(nova.getSubmarinos());
        couracado.setQuantidade(nova.getCouracados());
        portaAvioes.setQuantidade(nova.getPortaAvioes());
        playerUm = new Player(1, null, tabuleiro, criarSubmarinos(submarino.getQuantidade()), criarCouracados(couracado.getQuantidade()), criarPortaAvioes(portaAvioes.getQuantidade()));
        playerDois = new Player(2, null, tabuleiro, criarSubmarinos(submarino.getQuantidade()), criarCouracados(couracado.getQuantidade()), criarPortaAvioes(portaAvioes.getQuantidade()));
        novJogo = new Jogo(playerUm, playerDois, definicoesIniciais);
    }
    public static ArrayList<Parte> criarPosicoesOcupadas(int num){
        ArrayList<PosicoesOcupadas> novo = new ArrayList<>();
        for(int i=1;i<=num;i++){
            PosicoesOcupadas nPosicoesOcupadas = new PosicoesOcupadas(null, null);
            novo.add(nPosicoesOcupadas);
        }

        return novo;
    }
    public static ArrayList<Peca> criarSubmarinos(int num){
        ArrayList<Peca> novo = new ArrayList<>();
        for(int i=1;i<=num;i++){
            Peca nSubmarino = new Peca(i, definicoesIniciais.getSubmarinos(), null, null);
            novo.add(nSubmarino);
        }
        return novo;
    }
    public static ArrayList<Peca> criarCouracados(int num){
        ArrayList<Couracado> novo = new ArrayList<>();
        for(int i=1;i<=num;i++){
            Couracado nCouracado = new Couracado(definicoesIniciais.getCouracados()
            , Tipo.COURACADO, i, null);
            novo.add(nCouracado);
        }
        return novo;
    }
    public static ArrayList<Peca> criarPortaAvioes(int num){
        ArrayList<PortaAvioes> novo = new ArrayList<>();
        for(int i=1;i<=num;i++){
            PortaAvioes nPortaAvioes = new PortaAvioes(definicoesIniciais.getPortaAvioes(), Tipo.PORTA_AVIAO, i, null);
            novo.add(nPortaAvioes);
        }
        return novo;
    }
    public static Jogo obterJogo(){
        return novJogo;
    }
    public static void setRoot(String fxml) throws IOException {
        scene.setRoot(loadFXML(fxml));
    }

    private static Parent loadFXML(String fxml) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(App.class.getResource(fxml + ".fxml"));
        return fxmlLoader.load();
    }

    public static void main(String[] args) {
        launch();
    }

}