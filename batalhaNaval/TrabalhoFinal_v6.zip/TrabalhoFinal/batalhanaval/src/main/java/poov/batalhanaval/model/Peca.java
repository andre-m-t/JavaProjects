package poov.batalhanaval.model;

public abstract class Pecas {
    
    private int quantidade;
    private Tipo tipo;
    
    
    public int getQuantidade() {
        return quantidade;
    }
    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }
    public Tipo getTipo() {
        return tipo;
    }
    public void setTipo(Tipo tipo) {
        this.tipo = tipo;
    }


    public Pecas(int quantidade, Tipo tipo) {
        this.quantidade = quantidade;
        this.tipo = tipo;
    }


    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + quantidade;
        result = prime * result + ((tipo == null) ? 0 : tipo.hashCode());
        return result;
    }
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        Pecas other = (Pecas) obj;
        if (quantidade != other.quantidade)
            return false;
        if (tipo != other.tipo)
            return false;
        return true;
    }


    @Override
    public String toString() {
        return "Quantidade: " + quantidade + "Tipo: " + tipo;
    }
    
}
