package poov.batalhanaval.model;

import java.util.ArrayList;

import poov.batalhanaval.model.pecasdisp.Couracado;
import poov.batalhanaval.model.pecasdisp.PortaAvioes;
import poov.batalhanaval.model.pecasdisp.Submarino;

public class Player {
    private int id;
    private String nome;
    private Tabuleiro tabuleiro;
    private ArrayList<Submarino> submarinos;
    private ArrayList<Couracado> couracados;
    private ArrayList<PortaAvioes> portaAvioes;
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public String getNome() {
        return nome;
    }
    public void setNome(String nome) {
        this.nome = nome;
    }
    public Tabuleiro getTabuleiro() {
        return tabuleiro;
    }
    public void setTabuleiro(Tabuleiro tabuleiro) {
        this.tabuleiro = tabuleiro;
    }
    public ArrayList<Submarino> getSubmarinos() {
        return submarinos;
    }
    public void setSubmarinos(ArrayList<Submarino> submarinos) {
        this.submarinos = submarinos;
    }
    public ArrayList<Couracado> getCouracados() {
        return couracados;
    }
    public void setCouracados(ArrayList<Couracado> couracados) {
        this.couracados = couracados;
    }
    public ArrayList<PortaAvioes> getPortaAvioes() {
        return portaAvioes;
    }
    public void setPortaAvioes(ArrayList<PortaAvioes> portaAvioes) {
        this.portaAvioes = portaAvioes;
    }
    public Player(int id, String nome, Tabuleiro tabuleiro, ArrayList<Submarino> submarinos,
            ArrayList<Couracado> couracados, ArrayList<PortaAvioes> portaAvioes) {
        this.id = id;
        this.nome = nome;
        this.tabuleiro = tabuleiro;
        this.submarinos = submarinos;
        this.couracados = couracados;
        this.portaAvioes = portaAvioes;
    }
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + id;
        result = prime * result + ((nome == null) ? 0 : nome.hashCode());
        result = prime * result + ((tabuleiro == null) ? 0 : tabuleiro.hashCode());
        result = prime * result + ((submarinos == null) ? 0 : submarinos.hashCode());
        result = prime * result + ((couracados == null) ? 0 : couracados.hashCode());
        result = prime * result + ((portaAvioes == null) ? 0 : portaAvioes.hashCode());
        return result;
    }
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        Player other = (Player) obj;
        if (id != other.id)
            return false;
        if (nome == null) {
            if (other.nome != null)
                return false;
        } else if (!nome.equals(other.nome))
            return false;
        if (tabuleiro == null) {
            if (other.tabuleiro != null)
                return false;
        } else if (!tabuleiro.equals(other.tabuleiro))
            return false;
        if (submarinos == null) {
            if (other.submarinos != null)
                return false;
        } else if (!submarinos.equals(other.submarinos))
            return false;
        if (couracados == null) {
            if (other.couracados != null)
                return false;
        } else if (!couracados.equals(other.couracados))
            return false;
        if (portaAvioes == null) {
            if (other.portaAvioes != null)
                return false;
        } else if (!portaAvioes.equals(other.portaAvioes))
            return false;
        return true;
    }
    @Override
    public String toString() {
        return "Player [id=" + id + ", nome=" + nome + ", tabuleiro=" + tabuleiro + ", submarinos=" + submarinos
                + ", couracados=" + couracados + ", portaAvioes=" + portaAvioes + "]";
    }

    
}
