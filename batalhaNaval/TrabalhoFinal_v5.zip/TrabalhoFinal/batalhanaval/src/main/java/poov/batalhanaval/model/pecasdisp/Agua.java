package poov.batalhanaval.model.pecasdisp;
import poov.batalhanaval.model.Pecas;
import poov.batalhanaval.model.Posicao;
import poov.batalhanaval.model.Tipo;

public class Agua extends Pecas {
    private int id;
    private Posicao posicionar;
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public Posicao getPosicionar() {
        return posicionar;
    }
    public void setPosicionar(Posicao posicionar) {
        this.posicionar = posicionar;
    }
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = super.hashCode();
        result = prime * result + id;
        result = prime * result + ((posicionar == null) ? 0 : posicionar.hashCode());
        return result;
    }
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (!super.equals(obj))
            return false;
        if (getClass() != obj.getClass())
            return false;
        Agua other = (Agua) obj;
        if (id != other.id)
            return false;
        if (posicionar == null) {
            if (other.posicionar != null)
                return false;
        } else if (!posicionar.equals(other.posicionar))
            return false;
        return true;
    }
    public Agua(int quantidade, Tipo tipo, int id, Posicao posicionar) {
        super(quantidade, tipo);
        this.id = id;
        this.posicionar = posicionar;
    }
    @Override
    public String toString() {
        return "Agua [id=" + id + ", posicionar=" + posicionar + super.toString() +"]";
    }
}
