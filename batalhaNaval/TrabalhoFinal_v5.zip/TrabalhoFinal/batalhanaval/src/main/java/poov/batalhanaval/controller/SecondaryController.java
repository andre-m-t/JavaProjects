package poov.batalhanaval.controller;

import java.io.IOException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ColorPicker;
import javafx.scene.control.TextField;
import poov.batalhanaval.App;
import poov.batalhanaval.model.Jogo;

public class SecondaryController extends App {
     @FXML
    private Button goButton;

    @FXML
    private ColorPicker playerDoisCor;

    @FXML
    private TextField playerDoisTextField;

    @FXML
    private ColorPicker playerUmCor;

    @FXML
    private TextField playerUmTextField;

    @FXML
    private Button secondaryButton;

    @FXML
    void goSelected(ActionEvent event) {
        Jogo novo = App.obterJogo();
        novo.getPlayer_1().setNome(playerUmTextField.getText());
        novo.getPlayer_2().setNome(playerDoisTextField.getText());

        System.out.println(novo.getPlayer_1().getTabuleiro().getOcupadas().toString());
    }

    @FXML
    private void switchToPrimary() throws IOException {
        App.setRoot("primary");
    }
}