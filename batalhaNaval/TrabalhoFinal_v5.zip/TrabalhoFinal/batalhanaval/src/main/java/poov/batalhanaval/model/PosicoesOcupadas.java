package poov.batalhanaval.model;

public class PosicoesOcupadas {
    private Pecas peca;
    private Posicao posicao;
    public Pecas getPeca() {
        return peca;
    }
    public void setPeca(Pecas peca) {
        this.peca = peca;
    }
    public Posicao getPosicao() {
        return posicao;
    }
    public void setPosicao(Posicao posicao) {
        this.posicao = posicao;
    }
    public PosicoesOcupadas(Pecas peca, Posicao posicao) {
        this.peca = peca;
        this.posicao = posicao;
    }
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((peca == null) ? 0 : peca.hashCode());
        result = prime * result + ((posicao == null) ? 0 : posicao.hashCode());
        return result;
    }
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        PosicoesOcupadas other = (PosicoesOcupadas) obj;
        if (peca == null) {
            if (other.peca != null)
                return false;
        } else if (!peca.equals(other.peca))
            return false;
        if (posicao == null) {
            if (other.posicao != null)
                return false;
        } else if (!posicao.equals(other.posicao))
            return false;
        return true;
    }
    @Override
    public String toString() {
        return "\nPosicoesOcupadas [peca=" + peca + ", posicao=" + posicao + "]";
    }
    
}
