package poov.batalhanaval.model;

public class Tabuleiro {
    private int row;
    private int column;
    public int getRow() {
        return row;
    }
    public void setRow(int row) {
        this.row = row;
    }
    public int getColumn() {
        return column;
    }
    public void setColumn(int column) {
        this.column = column;
    }
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + row;
        result = prime * result + column;
        return result;
    }
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        Tabuleiro other = (Tabuleiro) obj;
        if (row != other.row)
            return false;
        if (column != other.column)
            return false;
        return true;
    }
    public Tabuleiro(int row, int column) {
        this.row = row;
        this.column = column;
    }
    public Tabuleiro(){

    }
    @Override
    public String toString() {
        return "\nLinhas: " + row + "\nColunas: " + column;
    }
}
