package poov.batalhanaval.model;

public class Peca {
    private int qtd;
    private Tipo tipo;
    public int getQtd() {
        return qtd;
    }
    public void setQtd(int qtd) {
        this.qtd = qtd;
    }
    public Tipo getTipo() {
        return tipo;
    }
    public void setTipo(Tipo tipo) {
        this.tipo = tipo;
    }
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + qtd;
        result = prime * result + ((tipo == null) ? 0 : tipo.hashCode());
        return result;
    }
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        Peca other = (Peca) obj;
        if (qtd != other.qtd)
            return false;
        if (tipo != other.tipo)
            return false;
        return true;
    }
    public Peca(int qtd, Tipo tipo) {
        this.qtd = qtd;
        this.tipo = tipo;
    }
    public Peca(){

    }
    @Override
    public String toString() {
        return "\nQuantidade: " + qtd + "\nTipo: " + tipo;
    }
    
}
