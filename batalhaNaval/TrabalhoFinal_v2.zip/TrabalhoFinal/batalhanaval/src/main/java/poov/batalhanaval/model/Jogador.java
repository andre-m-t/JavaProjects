package poov.batalhanaval.model;

public class Jogador {
    private int player;
    private String nome;
    private Tabuleiro tab;
    private Peca submarino;
    private Peca portaAvioes;
    private Peca couricado;
    public int getPlayer() {
        return player;
    }
    public void setPlayer(int player) {
        this.player = player;
    }
    public String getNome() {
        return nome;
    }
    public void setNome(String nome) {
        this.nome = nome;
    }
    public Tabuleiro getTab() {
        return tab;
    }
    public void setTab(Tabuleiro tab) {
        this.tab = tab;
    }
    public Peca getSubmarino() {
        return submarino;
    }
    public void setSubmarino(Peca submarino) {
        this.submarino = submarino;
    }
    public Peca getPortaAvioes() {
        return portaAvioes;
    }
    public void setPortaAvioes(Peca portaAvioes) {
        this.portaAvioes = portaAvioes;
    }
    public Peca getCouricado() {
        return couricado;
    }
    public void setCouricado(Peca couricado) {
        this.couricado = couricado;
    }
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + player;
        result = prime * result + ((nome == null) ? 0 : nome.hashCode());
        result = prime * result + ((tab == null) ? 0 : tab.hashCode());
        result = prime * result + ((submarino == null) ? 0 : submarino.hashCode());
        result = prime * result + ((portaAvioes == null) ? 0 : portaAvioes.hashCode());
        result = prime * result + ((couricado == null) ? 0 : couricado.hashCode());
        return result;
    }
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        Jogador other = (Jogador) obj;
        if (player != other.player)
            return false;
        if (nome == null) {
            if (other.nome != null)
                return false;
        } else if (!nome.equals(other.nome))
            return false;
        if (tab == null) {
            if (other.tab != null)
                return false;
        } else if (!tab.equals(other.tab))
            return false;
        if (submarino == null) {
            if (other.submarino != null)
                return false;
        } else if (!submarino.equals(other.submarino))
            return false;
        if (portaAvioes == null) {
            if (other.portaAvioes != null)
                return false;
        } else if (!portaAvioes.equals(other.portaAvioes))
            return false;
        if (couricado == null) {
            if (other.couricado != null)
                return false;
        } else if (!couricado.equals(other.couricado))
            return false;
        return true;
    }
    public Jogador(int player, String nome, Tabuleiro tab, Peca submarino, Peca portaAvioes, Peca couricado) {
        this.player = player;
        this.nome = nome;
        this.tab = tab;
        this.submarino = submarino;
        this.portaAvioes = portaAvioes;
        this.couricado = couricado;
        this.couricado.setTipo(Tipo.COURACADO);
        this.submarino.setTipo(Tipo.SUBMARINO);
        this.portaAvioes.setTipo(Tipo.PORTA_AVIAO);
    }
    public Jogador(){

    }
    @Override
    public String toString() {
        return "\nPlayer: " + player + "\nNome: " + nome + "\nTabuleiro: " + tab + "\nSubmarino: " + submarino
                + "\nPortaAvioes: " + portaAvioes + "\nCouricado: " + couricado;
    }
    
}
