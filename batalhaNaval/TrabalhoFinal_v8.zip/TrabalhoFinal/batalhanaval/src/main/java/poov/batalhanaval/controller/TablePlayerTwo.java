package poov.batalhanaval.controller;

public class TablePlayerTwo {
    
}
