package poov.batalhanaval.model;

public enum Tipo {
    AGUA("Água",1),
    SUBMARINO("Submarino", 2),
    PORTA_AVIAO("Porta Avião", 5),
    COURACADO("Couraçado",4);

    private String descricao;
    private int tamanho;
    
    private Tipo (String descricao, int tamanho){
        this.descricao = descricao;
        this.tamanho = tamanho;
    }
    public String geDescricao(){
        return descricao;
    }
    public int getTamanho(){
        return tamanho;
    }
}
