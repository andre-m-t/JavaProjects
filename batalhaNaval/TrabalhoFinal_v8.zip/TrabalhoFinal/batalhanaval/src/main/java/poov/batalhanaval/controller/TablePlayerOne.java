package poov.batalhanaval.controller;

import java.net.URL;
import java.util.ResourceBundle;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.RowConstraints;
import poov.batalhanaval.App;
import poov.batalhanaval.model.Jogo;


public class TablePlayerOne implements Initializable{

    @FXML
    private GridPane gridPane;
    private Jogo jogo = App.obterJogo();
    @Override
    public void initialize(URL location, ResourceBundle resources) {

        for(int i =0; i<jogo.getDefinicoes().getLinhas();i++){
            for(int j=0; j<jogo.getDefinicoes().getColunas();j++){
                Button nButton = new Button();
                nButton.setMinSize(40, 40);
                gridPane.add(nButton, i, j);
            }
        }

        // throw new UnsupportedOperationException("Unimplemented method 'initialize'");
    }

}
